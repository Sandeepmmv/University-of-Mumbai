/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypack;

import javax.ejb.Local;

/**
 *
 * @author Vishwakarma
 */
@Local
public interface studentbeanLocal {

    String insertmark(int rno, String n, String c, int s1, int s2, int s3);
    
}
