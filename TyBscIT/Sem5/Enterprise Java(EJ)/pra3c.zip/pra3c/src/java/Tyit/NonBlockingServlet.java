/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tyit;

import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "NonBlockingServlet", urlPatterns = {"/NonBlockingServlet"})
public class NonBlockingServlet extends HttpServlet {
protected void service(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
response.setContentType("text/html;charset=UTF-8");
try (PrintWriter out = response.getWriter()) {
out.println("<h1>FileReader</h1>");
String filename="/WEB-INF/booklist.txt";
ServletContext c=getServletContext();
InputStream in=c.getResourceAsStream(filename);
String path="http://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath()+"/ReadingNonBloclingServlet";
URL url=new URL(path);
HttpURLConnection conn=(HttpURLConnection)url.openConnection();
conn.setChunkedStreamingMode(2);
conn.setDoOutput(true);
conn.connect();
if(in!=null)
{
InputStreamReader inr=new InputStreamReader(in);
BufferedReader br = new BufferedReader(inr);
String text="";
System.out.println("Reading started....");
BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
while((text=br.readLine())!=null){
out.print(text+"<br>");

try{
Thread.sleep(1000);
out.flush();
}
catch(InterruptedException ex){}
}out.print("reading completed....");
bw.flush();
bw.close();
}
}
}
}