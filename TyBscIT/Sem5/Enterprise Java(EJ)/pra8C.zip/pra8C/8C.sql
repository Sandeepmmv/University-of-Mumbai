create table Book (BookNo int PRIMARY KEY AUTO_INCREMENT, BookName CHAR(50), AuthorName CHAR(100), Date CHAR(50));/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Vishwakarma
 * Created: Oct 11, 2024
 */

