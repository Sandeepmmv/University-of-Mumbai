create database qadb;

use qadb;


CREATE TABLE  quiz (qno CHAR(25),question CHAR(100), op1 CHAR(50), op2 CHAR(50), op3 CHAR(50), op4 CHAR(50),ans CHAR(20));

INSERT INTO quiz (qno, question, op1,op2,op3,op4,ans) VALUES ('001','What is the capital of India??','NewDelhi','Kolkata','Chennai','Mumbai','NewDelhi');

INSERT INTO quiz (qno, question, op1,op2,op3,op4,ans) VALUES ('002','Who was the First President of India??','Dr.RajendraPrasad','Dr.S.Radhakrishnan','RamNathKovind','V.V.Giri','Dr.RajendraPrasad');

INSERT INTO quiz(qno, question, op1,op2,op3,op4,ans) VALUES ('003','What is ORM','ObjectRatioMean','ObjectRotationMeasure','ObjectRelationMapping','OracleRequestManagement','ObjectRelationMapping');

INSERT INTO quiz(qno, question, op1,op2,op3,op4,ans) VALUES ('004','Unit of Energy is','Dozon','Kilo Meter ','Joul','Hertz','Joul');

INSERT INTO quiz(qno, question, op1,op2,op3,op4,ans) VALUES ('005',' is the smallest memory unit.','bit','byte','Kilo Byte','Giga Byte','bit');

