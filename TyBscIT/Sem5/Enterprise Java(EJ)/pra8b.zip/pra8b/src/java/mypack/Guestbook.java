/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypack;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Vishwakarma
 */
@Entity
@Table(name = "guestbook")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Guestbook.findAll", query = "SELECT g FROM Guestbook g")
    , @NamedQuery(name = "Guestbook.findByVno", query = "SELECT g FROM Guestbook g WHERE g.vno = :vno")
    , @NamedQuery(name = "Guestbook.findByVname", query = "SELECT g FROM Guestbook g WHERE g.vname = :vname")
    , @NamedQuery(name = "Guestbook.findByMsg", query = "SELECT g FROM Guestbook g WHERE g.msg = :msg")
    , @NamedQuery(name = "Guestbook.findByMdate", query = "SELECT g FROM Guestbook g WHERE g.mdate = :mdate")})
public class Guestbook implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "vno")
    private Integer vno;
    @Size(max = 50)
    @Column(name = "vname")
    private String vname;
    @Size(max = 100)
    @Column(name = "msg")
    private String msg;
    @Size(max = 50)
    @Column(name = "mdate")
    private String mdate;

    public Guestbook() {
    }

    public Guestbook(Integer vno) {
        this.vno = vno;
    }

    public Integer getVno() {
        return vno;
    }

    public void setVno(Integer vno) {
        this.vno = vno;
    }

    public String getVname() {
        return vname;
    }

    public void setVname(String vname) {
        this.vname = vname;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getMdate() {
        return mdate;
    }

    public void setMdate(String mdate) {
        this.mdate = mdate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (vno != null ? vno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Guestbook)) {
            return false;
        }
        Guestbook other = (Guestbook) object;
        if ((this.vno == null && other.vno != null) || (this.vno != null && !this.vno.equals(other.vno))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mypack.Guestbook[ vno=" + vno + " ]";
    }
    
}
