/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypack;
import java.sql.*;
import javax.ejb.Stateless;

/**
 *
 * @author Vishwakarma
 */
@Stateless
public class studentbean implements studentbeanLocal {

    @Override
    public String insertmark(int rno, String n, String c, int s1, int s2, int s3) {
        String msg="";
 
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root"); PreparedStatement stm1 = con.prepareStatement("insert into studentdb (rollno , name, class , sub1 ,sub2 ,sub3)values(?,?,?,?,?,?)");


        stm1.setInt(1,rno);	
        stm1.setString(2,n);
        stm1.setString(3,c);	
        stm1.setInt(4,s1);
        stm1.setInt(5,s2);
        stm1.setInt(6,s3);
      

        stm1.executeUpdate();
        msg="insert successful";


        }catch(Exception e)
                {
                    msg=""+e;
                }
        return msg;
    }
    
    
}


  