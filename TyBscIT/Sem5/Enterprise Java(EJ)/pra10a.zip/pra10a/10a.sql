CREATE TABLE emp (
  id INT PRIMARY KEY AUTO_INCREMENT, 
  firstName CHAR(20), 
  lastName CHAR(20)
);