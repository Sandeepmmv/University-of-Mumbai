package mypack;
import javax.enterprise.inject.New;
import javax.persistence.*;

public class PersistStudent
{

    
public static void main (String[] args)
{
EntityManagerFactory emf=Persistence.createEntityManagerFactory ("pra9aPU");
EntityManager em=emf.createEntityManager();
em.getTransaction().begin ();
StudentEntity st = new StudentEntity();
st.setSid(1);
st.setSname("ram");
st.setAge(22);

StudentEntity st2 = new StudentEntity();
st2.setSid(2);
st2.setSname("sharm");
st2.setAge(24);

em.persist (st);
em.persist (st2);
em.getTransaction ().commit ();
emf.close ();
em.close();
}
 
}

