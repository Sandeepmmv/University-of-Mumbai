/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypack;
import javax.persistence.*;

/**
 *
 * @author Vishwakarma
 */
@Entity
@Table(name="emptable")
public class empbook implements java.io.Serializable {
    @Id
    @GeneratedValue
    @Column(name="eno")
    private Integer empNo;
    @Column(name="ename")
    private String empName;
    @Column(name="eadd")
    private String eAddress;
    @Column(name="edate")
    private String eDate;
    
    public empbook(){}

    public Integer getEmpNo() {
        return empNo;
    }

    public void setEmpNo(Integer empNo) {
        this.empNo = empNo;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String geteAddress() {
        return eAddress;
    }

    public void seteAddress(String eAddress) {
        this.eAddress = eAddress;
    }

    public String geteDate() {
        return eDate;
    }

    public void seteDate(String eDate) {
        this.eDate = eDate;
    }

    
}
