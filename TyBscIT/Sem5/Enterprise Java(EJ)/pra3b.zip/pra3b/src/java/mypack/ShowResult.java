/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;  
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Vishwakarma
 */
@WebServlet(name = "ShowResult", urlPatterns = {"/ShowResult"})
public class ShowResult extends HttpServlet {
public void doGet(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
response.setContentType("text/html;charset=UTF-8");
PrintWriter out = response.getWriter();
try {
Class.forName("com.mysql.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qadb","root","root");
Statement stmt = con.createStatement();
ResultSet res = stmt.executeQuery("select ans from quiz");
//out.print(request.getParameter("qno"));
int count =0, qno=0;
while(res.next()){
if(res.getString(1).equals(request.getParameter(""+(++qno))))
{ count++;
out.println("<h1>Correct </h1>");
//out.println(res.getString(1));
//out.println(request.getParameter(""+qno));
}
else {
out.println("<h1>Incorrect </h1>");
//out.println(res.getString(1));
//out.println("cc"+request.getParameter(""+qno));
}

}
out.println("<h1>Your Score is "+count+" </h1>");
}catch(Exception e){out.println(e);}}}